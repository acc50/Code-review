#pragma once
const char* filetobuf(const char *file);