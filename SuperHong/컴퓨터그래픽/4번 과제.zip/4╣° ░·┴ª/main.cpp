
#include <gl/glew.h>

#include <gl/freeglut.h>
#include <gl/freeglut_ext.h>
#include <glm/glm.hpp>

#include <iostream>
#include <fstream>
#include <iterator>
#include <string>
#include <vector>
#include <array>
#include <random>

using namespace std;


GLvoid DrawScene(GLvoid);
GLvoid Reshape(int w, int h);
void ProcessMouseEvent(int button,int state,int x,int y);
void KeyInput(unsigned char key, int x, int y);

const std::string ReadStringFromFile(const std::string& filename);
bool CheckProgram(GLuint program);
GLuint CreateShader(GLenum shaderType, const std::string& source);
bool InitApp();
void UpdateVertexData();
void ChangeVertexColor();

enum Direction
{
	west = 0,
	east,
	north,
	south
};
struct point
{
	float fx;
	float fy;
	float r;
	float g;
	float b;
	Direction dir;

	point() :fx{ 0.0f }, fy{ 0.0f }, dir{ west }{};
};

struct point point[4];
bool gFillMode{ true };
bool gRotate{ false };
//���̴� ���α׷� ������Ʈ
GLuint gShaderProgram;
GLuint gVertexBufferObject[4];
std::array<glm::vec3,6> gVertices;
std::array<glm::vec3,6> gVertices2;
std::array<glm::vec3,6> gVertices3;
std::array<glm::vec3,6> gVertices4;
random_device rd;
	uniform_real_distribution<double> urd(0.0f,1.0f);
float r = urd(rd);
float g  = urd(rd) ;
float b  = urd(rd);



std::array<std::array<glm::vec3,6>,4> vertexArray;
int main(int argc,char **argv)
{
    glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH|GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(0, 0);
	glutInitWindowSize(800, 600);
	glutCreateWindow("Example1");

	glewExperimental = GL_TRUE;
	if(glewInit() != GLEW_OK)
	{
		std::cerr << "Unable to initialze GLEW" << std::endl;
		exit(EXIT_FAILURE);
	}
	else
	{
		std::cout << "GLEW Initiallize\n";
	}
	InitApp();
	glutDisplayFunc(DrawScene);
	glutIdleFunc(DrawScene);
	glutKeyboardFunc(KeyInput);	
	glutMouseFunc(ProcessMouseEvent);

	//glutTimerFunc(0, Timer, 0);
	
	glutMainLoop(); 
}



void KeyInput(unsigned char key, int x, int y)
{
	switch(key)
	{
	case 'F':
	case 'f':
		gFillMode = !gFillMode;

		if (gFillMode)
		{
			glPolygonMode(GL_FRONT, GL_FILL);
			glPolygonMode(GL_BACK, GL_FILL);
		}
		else
		{
			glPolygonMode(GL_FRONT, GL_LINE);
			glPolygonMode(GL_BACK, GL_LINE);
		}
		break;
		
	case 'M':
	case 'm':
		gRotate = true;
		
		break;
	
	case 'S':
	case 's':
		gRotate = false;
		
		break;
	case 'C':
	case 'c':
		ChangeVertexColor();
	
		break;
	case 'Q':
	case 'q':
		exit(1);
		break;

	}
	
}
GLvoid DrawScene()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glUseProgram(gShaderProgram);

	////���۸� ���ε�
	glBindBuffer(GL_ARRAY_BUFFER, gVertexBufferObject[0]);


	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), NULL);
	glEnableVertexAttribArray(0);


	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	static float t = 0.f;

	if (gRotate) {
		t += 0.016f;
		
	}
	else
	{
		t +=0.0f ;
		
	}
	GLuint tt = glGetUniformLocation(gShaderProgram, "u_time");
	glUniform1f(tt, t);


	GLuint time = glGetUniformLocation(gShaderProgram, "u_pos");
	glUniform2f(time, point[0].fx, point[0].fy);

	glDrawArrays(GL_TRIANGLES, 0, vertexArray[0].size());

	//���۸� ���ε�
	glBindBuffer(GL_ARRAY_BUFFER, gVertexBufferObject[1]);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), NULL);
	glEnableVertexAttribArray(0);


	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	glUniform2f(time, point[1].fx, point[1].fy);

	glDrawArrays(GL_TRIANGLES, 0, vertexArray[1].size());


	//���۸� ���ε�
	glBindBuffer(GL_ARRAY_BUFFER, gVertexBufferObject[2]);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), NULL);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	glUniform2f(time, point[2].fx, point[2].fy);
	glDrawArrays(GL_TRIANGLES, 0, vertexArray[2].size());

	//���۸� ���ε�
	glBindBuffer(GL_ARRAY_BUFFER, gVertexBufferObject[3]);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), NULL);
	glEnableVertexAttribArray(0);


	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	glUniform2f(time, point[3].fx, point[3].fy);
	glDrawArrays(GL_TRIANGLES, 0, vertexArray[3].size());
	//
	int attribPos = glGetAttribLocation(gShaderProgram, "vPos");
	int attribCol = glGetAttribLocation(gShaderProgram, "vColor");
	glEnableVertexAttribArray(attribPos);
	glEnableVertexAttribArray(attribCol);

	//���ε� ����
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glDisableVertexAttribArray(attribPos);
	glDisableVertexAttribArray(1);
	//���̴� ���α׷� ��� ����
	glUseProgram(0);

	glutSwapBuffers();
}
GLvoid Reshape(int w,int h)
{

	glViewport(0, 0, w, h);
	glOrtho(0.0, (float)w, (float)h, 0.0, -1.0, 1.0);
}

void ProcessMouseEvent(int button,int state,int x,int y)
{
	
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		/*GLuint l_xy =glGetAttribLocation(gShaderProgram, "xy");
		
		glUniform2f(l_xy,x,y);
		glDrawArrays()*/
		//gVertices[0] = glm::vec3(1.0f, 0.2f, 0.0f);		//top
		static int cnt = 0;

		point[cnt].fx = x / 400.f - 1;
		point[cnt++].fy = 1 - y / 300.f;
		cnt %= 4;
		UpdateVertexData();
	}
	glutPostRedisplay();
}

void ChangeVertexColor()
{
	float size = 0.3f;
	
	random_device rd;
	uniform_real_distribution<double> urd(0.0f,1.0f);

	r = urd(rd);
    g = urd(rd);
	b = urd(rd);
	point[0].r = r;
	point[0].g = g;
	point[0].b = b;

	gVertices = {
		glm::vec3(0, size, 0.0f),		//top
		glm::vec3(r,g,b),		//red
		glm::vec3(-size, -size, 0.0f),		//left
		glm::vec3(r,g,b),		//green
		glm::vec3(size, -size,0.0f),		//right
		glm::vec3(r,g,b)			//blue
		};
	 r = urd(rd);
	g = urd(rd);
	b = urd(rd);
	point[1].r = r;
	point[1].g = g;
	point[1].b = b;
		gVertices2 = {
			glm::vec3(0,size,0.0f),		//top
			glm::vec3(r,g,b),		//red
			glm::vec3(-size, -size,0.0f),		//left
			glm::vec3(r,g,b),		//green
			glm::vec3(size, -size,0.0f),		//right
			glm::vec3(r,g,b)		//blue
		};
	r = urd(rd);
	g = urd(rd);
	b = urd(rd);
	point[2].r = r;
	point[2].g = g;
	point[2].b = b;
		gVertices3 = {
			glm::vec3(0,size,0.0f),		//top
			glm::vec3(r,g,b),			//red
			glm::vec3(-size,-size,0.0f),		//left
			glm::vec3(r,g,b),			//green
			glm::vec3(size,-size,0.0f),		//right
			glm::vec3(r,g,b)		//blue
		};
	r = urd(rd);
	g = urd(rd);
	b = urd(rd);
	point[3].r = r;
	point[3].g = g;
	point[3].b = b;
	
		gVertices4 = {
			glm::vec3(0, size,0.0f),		//top
			glm::vec3(r,g,b),			//red
			glm::vec3(-size, -size,0.0f),		//left
			glm::vec3(r,g,b),			//green
			glm::vec3(size, -size,0.0f),		//right
			glm::vec3(r,g,b)		//blue
		};
	//



	


	//���� ���� ���ε� �� ������ ���
	glBindBuffer(GL_ARRAY_BUFFER, gVertexBufferObject[0]);
	glBufferData(GL_ARRAY_BUFFER, vertexArray[0].size() * sizeof(glm::vec3), &gVertices[0], GL_STATIC_DRAW);
	
	glBindBuffer(GL_ARRAY_BUFFER, gVertexBufferObject[1]);
	glBufferData(GL_ARRAY_BUFFER, vertexArray[1].size() * sizeof(glm::vec3), &gVertices2[0], GL_STATIC_DRAW);
	
	glBindBuffer(GL_ARRAY_BUFFER, gVertexBufferObject[2]);
	glBufferData(GL_ARRAY_BUFFER, vertexArray[2].size() * sizeof(glm::vec3), &gVertices3[0], GL_STATIC_DRAW);
	
	glBindBuffer(GL_ARRAY_BUFFER, gVertexBufferObject[3]);
	glBufferData(GL_ARRAY_BUFFER, vertexArray[3].size() * sizeof(glm::vec3), &gVertices4[0], GL_STATIC_DRAW);
}
void UpdateVertexData()
{
	float size = 0.3f;
	
		
	//
	
	gVertices = {
		glm::vec3(0, size, 0.0f),		//top
		glm::vec3(point[0].r,point[0].g,point[0].b),		//red
		glm::vec3(-size, -size, 0.0f),		//left
		glm::vec3(point[0].r,point[0].g,point[0].b),		//green
		glm::vec3(size, -size,0.0f),		//right
		glm::vec3(point[0].r,point[0].g,point[0].b)		//blue
		};

		gVertices2 = {
			glm::vec3(0,size,0.0f),		//top
			glm::vec3(point[1].r,point[1].g,point[1].b),		//red
			glm::vec3(-size, -size,0.0f),		//left
			glm::vec3(point[1].r,point[1].g,point[1].b),	//green
			glm::vec3(size, -size,0.0f),		//right
			glm::vec3(point[1].r,point[1].g,point[1].b)	//blue
		};
		gVertices3 = {
			glm::vec3(0,size,0.0f),		//top
			glm::vec3(point[2].r,point[2].g,point[2].b),		//red
			glm::vec3(-size,-size,0.0f),		//left
			glm::vec3(point[2].r,point[2].g,point[2].b),		//green
			glm::vec3(size,-size,0.0f),		//right
			glm::vec3(point[2].r,point[2].g,point[2].b)		//blue
		};

		gVertices4 = {
			glm::vec3(0, size,0.0f),		//top
			glm::vec3(point[3].r,point[3].g,point[3].b),		//red
			glm::vec3(-size, -size,0.0f),		//left
			glm::vec3(point[3].r,point[3].g,point[3].b),		//green
			glm::vec3(size, -size,0.0f),		//right
			glm::vec3(point[3].r,point[3].g,point[3].b)		//blue
		};


	


	//���� ���� ���ε� �� ������ ���
	glBindBuffer(GL_ARRAY_BUFFER, gVertexBufferObject[0]);
	glBufferData(GL_ARRAY_BUFFER, vertexArray[0].size() * sizeof(glm::vec3), &gVertices[0], GL_STATIC_DRAW);
	
	glBindBuffer(GL_ARRAY_BUFFER, gVertexBufferObject[1]);
	glBufferData(GL_ARRAY_BUFFER, vertexArray[1].size() * sizeof(glm::vec3), &gVertices2[0], GL_STATIC_DRAW);
	
	glBindBuffer(GL_ARRAY_BUFFER, gVertexBufferObject[2]);
	glBufferData(GL_ARRAY_BUFFER, vertexArray[2].size() * sizeof(glm::vec3), &gVertices3[0], GL_STATIC_DRAW);
	
	glBindBuffer(GL_ARRAY_BUFFER, gVertexBufferObject[3]);
	glBufferData(GL_ARRAY_BUFFER, vertexArray[3].size() * sizeof(glm::vec3), &gVertices4[0], GL_STATIC_DRAW);
	

}
bool InitApp()
{
	glClearColor(1.f, 1.f, 1.f, 1.f);

	glEnable(GL_DEPTH_TEST);
	glDisable(GL_CULL_FACE);
	glFrontFace(GL_CCW);

	if (gFillMode)
	{
		glPolygonMode(GL_FRONT, GL_FILL);
		glPolygonMode(GL_BACK, GL_FILL);
	}
	else
	{
		glPolygonMode(GL_FRONT, GL_LINE);
		glPolygonMode(GL_BACK, GL_LINE);
	}
	std::string vertexShaderSource = ReadStringFromFile("vertexShader.glvs");
	std::string fragShaderSource = ReadStringFromFile("fragment.glfs");

	GLuint vertShaderObj = CreateShader(GL_VERTEX_SHADER, vertexShaderSource);
	GLuint fragShaderObj = CreateShader(GL_FRAGMENT_SHADER, fragShaderSource);

	//���̴� ���α׷� ������Ʈ ����
	gShaderProgram = glCreateProgram();

	//���̴� ���α׷��� ���ؽ� �� �����׸�Ʈ ���̴� ���
	glAttachShader(gShaderProgram, vertShaderObj);
	glAttachShader(gShaderProgram, fragShaderObj);


	glBindAttribLocation(gShaderProgram, 0, "vPos");
	glBindAttribLocation(gShaderProgram, 1, "vColor");

	//���̴� ���α׷��� ���̴� ��ŷ �׸��� Ȯ��
	glLinkProgram(gShaderProgram);
	if(!CheckProgram(gShaderProgram))
	{
		glDeleteProgram(gShaderProgram);
		return false;
	}

	//���� ���̴� ���
	glDetachShader(gShaderProgram, vertShaderObj);
	glDetachShader(gShaderProgram, fragShaderObj);


	glDeleteShader(vertShaderObj);
	glDeleteShader(fragShaderObj);

	
	point[0].fx = -0.7f;
	point[0].fy = 0.7f;

	point[1].fx = 0.7f;
	point[1].fy = 0.7f;

	point[2].fx = -0.7f;
	point[2].fy = -0.7f;

	point[3].fx = 0.7f;
	point[3].fy = -0.7f;

	r = urd(rd);
    g = urd(rd);
	b = urd(rd);
	point[0].r = r;
	point[0].g = g;
	point[0].b = b;

	r = urd(rd);
    g = urd(rd);
	b = urd(rd);
	point[1].r = r;
	point[1].g = g;
	point[1].b = b;

	r = urd(rd);
    g = urd(rd);
	b = urd(rd);
	point[2].r = r;
	point[2].g = g;
	point[2].b = b;

	r = urd(rd);
    g = urd(rd);
	b = urd(rd);
	point[3].r = r;
	point[3].g = g;
	point[3].b = b;


	float size = 0.3f;
	gVertices = {
		glm::vec3(0, size, 0.0f),		//top
		glm::vec3(point[0].r,point[0].g,point[0].b),		//red
		glm::vec3(-size, -size, 0.0f),		//left
		glm::vec3(point[0].r,point[0].g,point[0].b),		//green
		glm::vec3(size, -size,0.0f),		//right
		glm::vec3(point[0].r,point[0].g,point[0].b)		//blue
		};

		gVertices2 = {
			glm::vec3(0,size,0.0f),		//top
			glm::vec3(point[1].r,point[1].g,point[1].b),		//red
			glm::vec3(-size, -size,0.0f),		//left
			glm::vec3(point[1].r,point[1].g,point[1].b),	//green
			glm::vec3(size, -size,0.0f),		//right
			glm::vec3(point[1].r,point[1].g,point[1].b)	//blue
		};
		gVertices3 = {
			glm::vec3(0,size,0.0f),		//top
			glm::vec3(point[2].r,point[2].g,point[2].b),		//red
			glm::vec3(-size,-size,0.0f),		//left
			glm::vec3(point[2].r,point[2].g,point[2].b),		//green
			glm::vec3(size,-size,0.0f),		//right
			glm::vec3(point[2].r,point[2].g,point[2].b)		//blue
		};

		gVertices4 = {
			glm::vec3(0, size,0.0f),		//top
			glm::vec3(point[3].r,point[3].g,point[3].b),		//red
			glm::vec3(-size, -size,0.0f),		//left
			glm::vec3(point[3].r,point[3].g,point[3].b),		//green
			glm::vec3(size, -size,0.0f),		//right
			glm::vec3(point[3].r,point[3].g,point[3].b)		//blue
		};

		//

		vertexArray[0] = gVertices;
		vertexArray[1] = gVertices2;
		vertexArray[2] = gVertices3;
		vertexArray[3] = gVertices4;

		//���� ���� ����
		glGenBuffers(1, &gVertexBufferObject[0]);
		glGenBuffers(1, &gVertexBufferObject[1]);
		glGenBuffers(1, &gVertexBufferObject[2]);
		glGenBuffers(1, &gVertexBufferObject[3]);



		//���� ���� ���ε� �� ������ ���
		glBindBuffer(GL_ARRAY_BUFFER, gVertexBufferObject[0]);
		glBufferData(GL_ARRAY_BUFFER, vertexArray[0].size() * sizeof(glm::vec3), &gVertices[0], GL_STATIC_DRAW);

		glBindBuffer(GL_ARRAY_BUFFER, gVertexBufferObject[1]);
		glBufferData(GL_ARRAY_BUFFER, vertexArray[1].size() * sizeof(glm::vec3), &gVertices2[0], GL_STATIC_DRAW);

		glBindBuffer(GL_ARRAY_BUFFER, gVertexBufferObject[2]);
		glBufferData(GL_ARRAY_BUFFER, vertexArray[2].size() * sizeof(glm::vec3), &gVertices3[0], GL_STATIC_DRAW);

		glBindBuffer(GL_ARRAY_BUFFER, gVertexBufferObject[3]);
		glBufferData(GL_ARRAY_BUFFER, vertexArray[3].size() * sizeof(glm::vec3), &gVertices4[0], GL_STATIC_DRAW);

	return true;


}


const std::string ReadStringFromFile(const std::string& filename) {
	std::ifstream f(filename);

	if (!f.is_open())
		return "";

	return std::string(std::istreambuf_iterator<char>(f),
		std::istreambuf_iterator<char>());
}

GLuint CreateShader(GLenum shaderType, const std::string& source) {
	GLuint shader = glCreateShader(shaderType);
	if (shader == 0)
		return 0;

	// set shader source
	const char* raw_str = source.c_str();
	glShaderSource(shader, 1, &raw_str, NULL);

	// compile shader object
	glCompileShader(shader);

	// check compilation error
	if (!CheckProgram(shader)){
		glDeleteShader(shader);
		return 0;
	}

	return shader;
}


bool CheckProgram(GLuint program) {
	GLint state;
	glGetProgramiv(program, GL_LINK_STATUS, &state);
	if (GL_FALSE == state) {
		int infologLength = 0;
		glGetProgramiv(program, GL_INFO_LOG_LENGTH, &infologLength);
		if (infologLength > 1){
			int charsWritten = 0;
			char *infoLog = new char[infologLength];
			glGetProgramInfoLog(program, infologLength, &charsWritten, infoLog);
			std::cout << infoLog << std::endl;
			delete[] infoLog;
		}
		return false;
	}
	return true;
}